package com.example.calendarcountdowncameronholloman;

import android.content.Intent;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.text.BreakIterator;

public class Calendar extends AppCompatActivity {

    private EditText mEventText;
    private EditText mDateText;

    private Question mQuestion;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        mEventText = findViewById(R.id.eventText);
        mDateText = findViewById(R.id.dateText);

    }


    public void addEvent(View view) {
        mQuestion.setText(mEventText.getText().toString());
        mQuestion.setAnswer(mDateText.getText().toString());
    }

    public void messaging(View view) {
        Intent intent = new Intent(this, Calendar.class);
        startActivity(intent);
    }
}
