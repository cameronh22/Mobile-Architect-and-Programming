package com.example.calendarcountdowncameronholloman;

public class Question {
    public void setText(String toString) {
    }

    public void setAnswer(String toString) {
    }
}
